# ToolsGroup — Case Study Preparation
**Pedro Canário · April 2026**
*Principal Technical PM – Agentic AI*

---

## The Mission

You are coming into the middle of a conversation. A small startup-mode team inside ToolsGroup is building an agentic platform that will launch in summer 2026. The role is to find unmet needs and own the proposition.

The deliverables will likely be:
- A **30/60/90 day plan** — your personal execution arc
- A **3-4-3 roadmap** — 3 months detail, 4 quarters direction, 3 years vision
- A **product proposition** — your POV on what gets built and why
- A **panel presentation** — to Jeanette, Warren, and the product designer

These are not four separate documents. They are the same thinking at four zoom levels.

---

## The Strategic Spine — 3-4-3

### 3 Months — High Detail
*What you are actually shipping*

Launch the assistant layer to 2-5 early adopter companies. Prove that planners will trust an agent that explains its reasoning. Measure adoption, trust signals, and exception handling behavior. Define what "good" looks like before building more.

### 4 Quarters — Medium Detail
*Directional bets and milestones*

- **Q1 (Summer 2026):** Early adopter launch. Assistant layer live. Glass box UX validated with real planners.
- **Q2 (Autumn 2026):** Automation layer. Agents that act, not just recommend. Guardrails defined. Human-in-the-loop frameworks in place.
- **Q3 (Winter 2026/27):** Platform layer begins. Internal teams start building on the agentic dev platform. API contracts defined.
- **Q4 (Spring 2027):** External platform readiness. Third party integrations. Sales enablement package complete.

### 3 Years — Low Detail
*Vision and market position*

ToolsGroup is the agentic platform standard for supply chain planning. Probabilistic forecasting plus explainable AI agents is the differentiated stack no competitor can replicate quickly. The platform layer means ToolsGroup is infrastructure, not just software. Exit narrative: we are not a planning tool. We are the operating system for supply chain intelligence.

---

## The 30/60/90 Day Plan
*Your personal execution arc within the first 3 months*

### First 30 Days — Listen and Map
- Shadow demand planners at 2-3 early adopter companies (DILO)
- Map the current product architecture — what exists, what is being built, what is missing
- Audit existing agent behavior — what it explains, what it doesn't, where trust breaks
- Meet every person on the incubation team
- Identify the single biggest unmet need nobody has named yet

### First 60 Days — Define and Propose
- Deliver a glass box UX proposal — how agent reasoning gets surfaced to planners
- Define the trust framework — what a planner needs to see before they let an agent act
- Propose the early adopter feedback loop — how 2-5 companies become your design partners
- Align with Warren and Jeanette on the summer launch scope
- Define done — what does a successful summer launch actually mean

### First 90 Days — Ship and Measure
- First agent interaction live with early adopters
- Trust metrics defined and baseline established
- Unmet needs documented and prioritized
- 3-4-3 roadmap presented to leadership
- Sales enablement draft — how do you sell an agent that explains itself

---

## The Four Pillars — Research and Preparation

---

### Pillar 1 — Know the User
*DILO of a Demand Planner*

**What we need to understand:**
- What does a demand planner's day look like hour by hour
- Where do they get stuck — data gaps, system trust failures, too many alerts
- What decisions do they make manually that an agent could support
- What would make them trust an agent recommendation versus ignore it
- What is the cost of a wrong recommendation in their world

**Key insight from today's interview:**
Jeanette said the role needs to obsess over the customer and establish system trust. Trust is not a feature. It is the product. A planner who does not trust the agent will stop using it. The entire platform collapses without adoption.

**Research to do:**
- [ ] Find published DILO research on demand planners and S&OP roles
- [ ] Review ToolsGroup customer case studies for planner pain points
- [ ] Pull any available research on AI adoption barriers in supply chain
- [ ] Map the exception management problem — why do planners get overwhelmed by alerts

**Your existing insight:**
Humans trust systems that surface the lineage of their own decisions. Social proof at machine scale. The agent is not an oracle. It is a synthesizer of accumulated human decisions made legible. When a planner sees "this recommendation is consistent with how your team handled similar demand spikes 47 times over 3 years" — they trust it. Not because AI said so. Because they said so, aggregated.

---

### Pillar 2 — Know the Product
*Architecture and current state*

**What Jeanette told you today:**
- Three layer architecture:
  - **Layer 1 — Assistant:** Agents trained on their SaaS solutions, explain actions
  - **Layer 2 — Automation:** Agents that act
  - **Layer 3 — Platform:** Infrastructure that other teams build on
- Team is in startup mode, small
- Launch in summer 2026
- Initial release scope defined
- Early adopter program: 2-5 companies
- Definition of done and sales enablement in progress

**Core existing products:**
- **SO99+** — flagship demand planning engine, probabilistic forecasting, multi-echelon inventory optimization
- **PriceAI** — AI-driven pricing and analysis, integrated with SO99+ December 2025
- **S&OP solution** — cross-functional planning workflow, role-based task management

**ToolsGroup's technical differentiator:**
Probabilistic forecasting. Not one number. A range with confidence levels. This is what separates them from deterministic competitors. The agent layer sits on top of this — which means agents can express uncertainty, not just recommendations. That is the glass box opportunity.

**Research to do:**
- [ ] Map SO99+ core workflows — what does a planner actually do in the product today
- [ ] Understand the current agent architecture — what has been built for summer
- [ ] Identify where the glass box layer would sit in the existing product
- [ ] Understand the Agentic Dev Platform scope — what do internal teams need to build on it

---

### Pillar 3 — Know the Market
*Competitive landscape and strategic context*

**ToolsGroup's position:**
- 450+ customers, 220+ employees
- Offices: Milan, Turin, Barcelona, California, Boston
- 2026 Gartner Magic Quadrant — Supply Chain Planning Solutions, Discrete Industries
- Recognized for Ability to Execute and Completeness of Vision
- $82.3M annual revenue

**Competitive landscape:**
- **Blue Yonder** — enterprise planning, strong execution depth, deep WMS integration
- **Manhattan Associates** — execution focused, strong WMS/OMS, moving into planning
- **Kinaxis** — strong S&OP, simulation-heavy, Maestro agentic platform announced
- **o9 Solutions** — IBP focused, strong data model, growing fast
- **Oracle/SAP** — platform plays, broad but not deep on probabilistic

**ToolsGroup's competitive risk:**
Kinaxis is building Maestro — their agentic layer. o9 is growing. Blue Yonder has deep enterprise relationships. ToolsGroup wins on probabilistic depth and mid-market agility but could be squeezed between enterprise incumbents and fast-moving specialists.

**The on-prem question:**
Jeanette confirmed their market is $200M-$500M enterprise. This segment has the highest data sovereignty sensitivity. Algorithmic compression is making local deployment viable. No answer from ToolsGroup yet on this — you surfaced the question and she thought out loud. Watch this space.

**Research to do:**
- [ ] Deep dive on Kinaxis Maestro — what have they actually shipped
- [ ] Map the $200M-$500M enterprise customer profile — what are their data sovereignty concerns
- [ ] Find any published research on AI trust barriers in enterprise supply chain
- [ ] Competitive positioning on explainability — who else is doing glass box

---

### Pillar 4 — The Proposition
*Your POV on what gets built and why*

**The core thesis:**
ToolsGroup has the most sophisticated probabilistic forecasting engine in the mid-market. The agentic layer will fail to achieve adoption if it behaves like a black box. The competitive differentiation is not agents that act. It is agents that explain, using the lineage of human decisions already inside the system. This is the glass box proposition.

**The trust framework:**
Three things a planner needs before they trust an agent:
1. **Lineage** — show me this recommendation is based on decisions like mine made by people like me
2. **Confidence** — show me the range, not just the number. ToolsGroup already does this in SO99+. The agent inherits it.
3. **Control** — let me approve before the agent acts. Guardrails are not a limitation. They are the product.

**The unmet need:**
No one has connected ToolsGroup's probabilistic model to the agent's explanation layer. The math is there. The UX bridge is not. That is the gap. That is the proposition.

**The glass box UX:**
When an agent recommends an action, the planner sees:
- What it is recommending
- Why — the demand signals that triggered it
- How confident — the probabilistic range
- What happened last time — historical decisions in similar conditions
- What to do — approve, modify, or override

This is not a chatbot. This is a structured decision environment with AI inside it. ToolsGroup already described it this way publicly. The gap is building the UX layer that makes the AI's reasoning legible to a human who needs to own the decision.

---

## Key Vocabulary — Know Cold

| Term | Definition |
|------|-----------|
| S&OP | Sales & Operations Planning. Monthly cross-functional process aligning demand and supply. 3-18 month horizon. |
| S&OE | Sales & Operations Execution. Weekly/daily. Manages deviation from the S&OP plan. 0-8 week horizon. |
| Demand sensing | Using real-time signals to correct the forecast in near real time |
| Probabilistic forecasting | A range with confidence levels, not a single number. ToolsGroup's core identity. |
| Consensus forecast | The agreed number that comes out of S&OP after cross-functional alignment |
| MEIO | Multi-Echelon Inventory Optimization. Optimizing inventory across the whole network simultaneously |
| Exception management | Surfacing only what needs human attention. Signal to noise is the adoption problem. |
| Planner agent | An AI that monitors conditions, runs scenarios, recommends actions. Human approves or overrides. |
| Forecast bias | Systematic error in one direction. Why planners stop trusting the number. |
| DILO | Day In the Life Of. Observational research methodology. |
| Glass box | AI that explains its reasoning visibly to the user. Opposite of black box. |
| Human-in-the-loop | Guardrail architecture where humans approve before agents act |
| RAG | Retrieval Augmented Generation. How agents access relevant context from a knowledge base |
| Evals | Evaluation frameworks for testing agent output quality |
| Guardrails | Rules that constrain agent behavior and require human approval thresholds |

---

## Research Task List — Priority Order

**This week (before case study is assigned):**

- [ ] **DILO research** — find published demand planner day-in-the-life studies or build one from customer case studies
- [ ] **Kinaxis Maestro** — what have they actually shipped vs announced
- [ ] **SO99+ workflow map** — understand the core planner journey in the existing product
- [ ] **AI trust research** — published studies on why enterprise users resist AI recommendations
- [ ] **ToolsGroup customer case studies** — extract planner pain points from their own published material
- [ ] **Competitive explainability audit** — who else is doing glass box and how

**Once case study is assigned:**

- [ ] Define the early adopter program structure — 2-5 companies, what they get, what you get
- [ ] Write the trust framework — three things a planner needs before they act on an agent
- [ ] Build the glass box UX proposal — what the agent explanation layer looks like
- [ ] Draft the 30/60/90 with specific named actions
- [ ] Build the 3-4-3 with the three layer architecture as the spine
- [ ] Write the proposition — one page, sharp, your POV
- [ ] Build the presentation — last, once thinking is solid

---

## The Questions You Asked — For Reference

**Question 1 (asked, landed well):**
"With data sovereignty pressures and local deployment costs dropping, does ToolsGroup consider a pivot if customers start asking for on-prem?"
*Her response: surprised, thought out loud, confirmed they hadn't addressed it yet.*

**Question 2 (asked):**
"What does this team look like today? Has it started or are they in planning?"
*Her response: startup mode, small team, launch in summer.*

**Question 3 (asked):**
"How do you see this role? Self-contained or working horizontally?"
*Her response: IC role reporting to Jeanette, high visibility, working across the team.*

---

## What You Know About The People

**Jeanette Barlow — CPO**
IBM Sterling background — supply chain execution. Instacart VP Product. Joined ToolsGroup July 2025. Passionate about probabilistic forecasting and moving customers from reactive firefighting to strategic performance. Genuine, excited, collaborative. Talks more than she listens when she's interested. Good mother who pushed analog values in a digital world. Probably Democrat. Surprised by your on-prem question. Excited about the digital twin framing.

**Warren Wilbee — CTO**
Your mentor. Flew to Porto to keep you at Körber. ADHD. Sees your pattern. Co-product managing the agentic platform with Jeanette right now. Knows what you're capable of.

**Sean Elliott — CEO**
Hired you himself at Körber. Former CTO at Körber Supply Chain, Co-CEO. Friends. Referred you to ToolsGroup.

---

## The Line That Closes Everything

*If asked why ToolsGroup:*

"I'm at a point in my career where I need to move sideways to go up. GenAI product strategy is where I'm placing my bet. And I'd rather make that move with people who already know what I'm capable of."

---

*Built April 13, 2026. The day of the interview.*
*Updated as case study prep progresses.*
